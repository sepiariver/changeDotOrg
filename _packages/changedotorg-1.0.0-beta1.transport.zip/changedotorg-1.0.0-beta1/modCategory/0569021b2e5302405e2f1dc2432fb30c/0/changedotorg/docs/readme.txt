----------------------
changeDotOrg
----------------------
Version: 1.0.0-beta1
Author: YJ Tso
Contact: yj@modx.com
----------------------

changeDotOrg uses the Change.org API to read data from a 
petition for re-use on the petition's MODX website.

Possible uses include:
- Fetching and displaying the number of signatures
- Fetching and displaying the latest reasons for signing
- Fetching and displaying news updates from the petition
- Subsequent releases will allow for adding signatures via the API